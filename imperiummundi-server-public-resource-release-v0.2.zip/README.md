# imperiummundi-server-public-resource
 server resource for imperiummundi server

<a rel="license" href="http://creativecommons.org/licenses/by-nc/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc/4.0/88x31.png" /></a><br />assets created by theuwufurry are licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc/4.0/">Creative Commons Attribution-NonCommercial 4.0 International License</a>.

emissive texutres created by https://github.com/ShockMicro

3d spawn eggs by https://www.planetminecraft.com/texture-pack/spawn-egg-3d/
